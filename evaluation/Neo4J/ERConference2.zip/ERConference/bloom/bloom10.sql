		
GEO AddLabel {
	target: Node
	label: "Person"
}
				
				
				
				
				
GEO AddLabel {
	target: Node
	label: "Provider"
}
				
				
				
				
				
GEO AddRelationshipType {
type: "IS"
}
				
GEO AddLabel {
	target: Node
	label: "Product"
}
GEO AddProperty {
target: Node(label="Product")
property { name: "name", dtype: "STRING", default: "" }
}
				
				
GEO AddRelationshipType {
type: "PURCHASED"
}
				
				
				
