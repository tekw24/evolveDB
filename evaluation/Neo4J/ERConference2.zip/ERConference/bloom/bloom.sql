Add node with label "Person"
				
				
				
				
				
Add node with label "Provider"
				
				
				
Rename property "name" of node with label "Parent invalid" to property "shopName"
				
				
Add relationship with type "IS"
				
Add node with label "Product"
Add property "Product" to node with label "name" 
    starting at relationship with type "STRING", ending at relationship with type ""
				
Rename label "_Bloom_Perspective_" of node with label "_Bloom_Perspective_" to label "BloomPerspective"
				
Add relationship with type "PURCHASED"
				
				
				
