		
Add node with label "Person"
Add property "Person" to node with label "lastName" 
Add property "Person" to node with label "fullName" 
Add property "Person" to node with label "firstName" 
				
				
				
				
				
				
Add node with label "Provider"
Add property "Provider" to node with label "provider" 
				
				
Rename property "name" of node with label "Shop" to property "shopName"
				
				
Add relationship with type "IS"
				
Add node with label "Product"
Add property "Product" to node with label "name" 
				
Rename label "_Bloom_Perspective_" of node with label "_Bloom_Perspective_" to label "BloomPerspective"
				
				
Add relationship with type "PURCHASED"
				
				
				
