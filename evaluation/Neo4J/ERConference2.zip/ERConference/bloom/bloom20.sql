		
CREATE_LABEL: Add nodelabel Person
Add property lastName with datatype STRING to nodelabel with label Person 
Add property fullName with datatype STRING to nodelabel with label Person 
Add property firstName with datatype STRING to nodelabel with label Person 
CREATE_EDGE_TYPE: Add relationship_type :PURCHASED(:Product, :Purchase) with label PURCHASED starting from :Product ending at :Purchase
CREATE_EDGE_TYPE: Add relationship_type :IS(:AccountHolder, :Person) with label IS starting from :AccountHolder ending at :Person
CREATE_EDGE_TYPE: Add relationship_type :IS(:AccountHolder:Flagged, :Person) with label IS starting from :AccountHolder:Flagged ending at :Person
CHANGE_TYPE: Change datatype of property name with nodelabel Shop from STRING to STRING
ADD_REFERENCE_OR_MEMBER: null
CREATE_LABEL: Add nodelabel Provider
Add property provider with datatype STRING to nodelabel with label Provider 
ADD_LABEL_TO_NODE_TYPE: Add nodelabel Provider to nodetype PhoneNumber, Provider
CHANGE_NAME: Rename property name of node with label Shop to property shopName

CREATE_NODE_TYPE: null

CREATE_LABEL: Add relationship with type IS
CREATE_LABEL: Add nodelabel Product
Add property name with datatype STRING to nodelabel with label Product 
CHANGE_NAME: Rename label _Bloom_Perspective_ of node with label _Bloom_Perspective_ to label BloomPerspective
ADD_REFERENCE_OR_MEMBER: null
CREATE_LABEL: Add relationship with type PURCHASED

CREATE_NODE_TYPE: null
ADD_REFERENCE_OR_MEMBER: null